const AboutTemplate = {
    template: `<div id="info">
    <img src="./img/logo.png" alt="Logo de La Libroteca" class="logo">

    <div id="informacion" class="container">
    <h3>¡Bienvenido a La Libroteca!</h3>
    <br>
    <p>En La Libroteca, no solo vendemos libros, sino que también fomentamos una comunidad 
    apasionada de lectores ávidos. Nos dedicamos a alimentar la pasión por la lectura y a 
    desbloquear las puertas de la imaginación a través de las historias que llenan nuestras estanterías.</p>
    <br>
    <p>Nuestra misión es simple pero poderosa: conectarte con los libros que transformarán tus 
    momentos de lectura en viajes inolvidables. Desde nuestros humildes comienzos hasta nuestro 
    vibrante presente, hemos sido un faro para los amantes de la literatura, ofreciendo no solo un 
    lugar donde comprar libros, sino un refugio donde las palabras cobran vida y los personajes se convierten 
    en compañeros de aventura.</p>
    <br>
    <p>En La Libroteca, encontrarás una selección cuidadosamente curada que abarca desde los clásicos atemporales 
    hasta las últimas novedades literarias. Nuestro compromiso con la excelencia y la diversidad garantiza que cada lector, 
    sin importar sus gustos o intereses, encuentre una historia que le inspire, le entretenga y le haga reflexionar.</p>
    <br>
    <p>Únete a nosotros en este viaje, donde cada página es una invitación a explorar nuevos mundos, descubrir nuevas perspectivas 
    y sumergirse en la belleza infinita de la palabra escrita. En La Libroteca, la aventura de la lectura nunca termina, y cada libro 
    es una puerta abierta hacia el conocimiento, la emoción y la maravilla.</p>
    <br>
    <p>Descubre, conecta y celebra la magia de la literatura en La Libroteca, donde los libros son mucho más que simples páginas: 
    son el alma de nuestras vidas y el corazón de nuestra comunidad.</p>
    <br>
    <h4>¡Bienvenido a La Libroteca, donde los sueños se convierten en historias y las historias se convierten en realidad!</h4>

    </div>
</div>`
};

const FormularioTemplate = {
    template: `
    <div class="login-container">
    <h2>Iniciar Sesión</h2>
    <form action="#">
      <div class="form-group">
        <label for="username">Nombre de Usuario:</label>
        <input type="text" id="username" name="username" required>
      </div>
      <div class="form-group">
        <label for="password">Contraseña:</label>
        <input type="password" id="password" name="password" required>
      </div>
      <div class="form-group">
        <button type="submit" id='iniciar'>Iniciar Sesión</button>
      </div>
    </form>
  </div>
    `
};

const RegistroTemplate = {
    template: `
    
    <div class="container">
    <h1>¿Un nuevo pingüino? ¡Regístrate!</h1>
    <br>
    <form id="registro-form">
    <div class="form-group">
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required>
    </div>
    <div class="form-group">
        <label for="apellido">Apellido:</label>
        <input type="text" id="apellido" name="apellido" required>
    </div>
    <div class="form-group">
        <label for="email">Correo Electrónico:</label>
        <input type="email" id="email" name="email" required>
    </div>
    <div class="form-group">
        <label for="password">Contraseña:</label>
        <input type="password" id="password" name="password" required>
    </div>
    <div class="form-group">
        <label for="confirm-password">Confirmar Contraseña:</label>
        <input type="password" id="confirm-password" name="confirm-password" required>
    </div>
    <div class="form-group">
        <label for="tarjeta">Número de Tarjeta Bancaria:</label>
        <input type="text" id="tarjeta" name="tarjeta" pattern="[0-9]{16}" maxlength="16" placeholder="Ingrese los 16 dígitos" required>
    </div>
    <div class="form-group">
        <button type="submit">Registrarse</button>
    </div>
</form>

</div>`
}

const MainTemplate = {
    template: `
    <div class="recomendacion container">
    <h3>Recomendación del Día</h3>
    <div class="contenido">
        <img src="./img/blatahers.png" alt="Imagen de la recomendación">
        <div class="descripcion">
            <h4>Título del Libro</h4>
            <p>Autor: Nombre del Autor</p>
            <p>Género: Género del Libro</p>
            <p>Sinopsis: Breve descripción o sinopsis del libro recomendado.</p>
            <a href="#">Ver más</a>
        </div>
    </div>
</div>

    `
}

//creación de la VueApp
const app = Vue.createApp({
    data() {
        return {
            componenteActual: 'main-template',
            loggedIn: false
        };
    },
    methods: {
        mostrarPlantilla(componente) {
            if (componente === 'about') {
                this.componenteActual = 'about-template';
            } else if (componente === 'formulario') {
                if (this.loggedIn){
                    this.componenteActual = 'formulario-template'; 
                } else {
                    this.componenteActual = 'registro-template';
                }
                
            }
        }
    }
});

app.component('about-template', AboutTemplate);
app.component('main-template', MainTemplate);
app.component('formulario-template', FormularioTemplate);
app.component('registro-template', RegistroTemplate);

app.mount('#app');
