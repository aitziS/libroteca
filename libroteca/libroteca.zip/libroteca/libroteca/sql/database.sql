create database Libroteca;

use Libroteca;

create table libros(
    id int primary key auto_increment,
    titulo varchar(100),
    autor varchar(100),
    editorial varchar(100),
    isbn varchar(100),
    precio float,
    descripcion text,
    stock int
);

create table clientes (
    id int primary key auto_increment,
    nombre varchar(100),
    apellidos varchar(100),
    email varchar(100),
    telefono varchar(100),
    tarjeta varchar(100),
    contrasena varchar(100)
);
